/* SeaMercy storefront preview — no live payment, accounts, CRM, or affiliate tracking. */
(() => {
  'use strict';
  const WHATSAPP_NUMBER = '27698926949'; // Verify SeaMercy's public order number before launch.
  const DELIVERY = { locker: 80, door: 120, collect: 0 }; // Estimates: confirm with provider.
  const products = [
    {id:'plain-gel',title:'Golden Sea Moss Gel 375ml',type:'gel',category:'Sea Moss Gels',price:150,tone:'plain',tag:'THE ORIGINAL',accent:'#aaa96c',label:'GOLDEN SEA MOSS',description:'Our original Sea Moss Gel, crafted for simple everyday routines. Check the packaging for ingredients, storage, and use instructions.'},
    {id:'honey-gel',title:'Raw Honey Sea Moss Gel 375ml',type:'gel',category:'Sea Moss Gels',price:199,tone:'honey',tag:'POPULAR PICK',accent:'#b79046',label:'RAW HONEY',description:'A honey-infused addition to our Sea Moss Gel range. Contains honey; not suitable for infants under one year.'},
    {id:'moringa-gel',title:'Moringa Sea Moss Gel 375ml',type:'gel',category:'Sea Moss Gels',price:199,tone:'moringa',tag:'GREEN GOODNESS',accent:'#6d995b',label:'MORINGA INFUSED',description:'Sea Moss Gel with a moringa-inspired twist. Full ingredient details and any allergens will be confirmed on the finished label.'},
    {id:'hibiscus-gel',title:'Hibiscus Sea Moss Gel 375ml',type:'gel',category:'Sea Moss Gels',price:199,tone:'hibiscus',tag:'FLOWER POWER',accent:'#b96e86',label:'HIBISCUS INFUSED',description:'A botanical variant of our Sea Moss Gel collection. We recommend reviewing the final ingredient label before ordering.'},
    {id:'moringa-capsules',title:'Moringa + Sea Moss Capsules',type:'capsules',category:'Wellness',price:349,tone:'wellness',tag:'WELLNESS ESSENTIAL',accent:'#72935e',label:'MORINGA + SEA MOSS',description:'A supplement product in the SeaMercy range. Read the official label for ingredients and directions. Not a replacement for medical care.'},
    {id:'facial-serum',title:'SeaMercy Facial Serum 30ml',type:'dropper',category:'Skincare',price:120,tone:'skincare',tag:'SKINCARE RITUAL',accent:'#b7b986',label:'FACIAL SERUM',description:'Facial care for your personal skincare routine. Patch test new products and follow the directions on the final label.'},
    {id:'glow-soap',title:'SeaMercy Glow Soap',type:'soap',category:'Skincare',price:149,tone:'skincare',tag:'EVERYDAY CARE',accent:'#a59b66',label:'GLOW SOAP',description:'An everyday cleansing bar from our skincare collection. Check the ingredients if you have sensitive skin.'},
    {id:'vitamin-e',title:'Vitamin E Capsules',type:'capsules',category:'Wellness',price:120,tone:'wellness',tag:'WELLNESS ESSENTIAL',accent:'#a5ad72',label:'VITAMIN E',description:'Vitamin E capsules. The final label will clarify intended use, ingredients and important cautions.'},
    {id:'face-mask',title:'Turmeric & Sea Moss Face Mask',type:'jar',category:'Skincare',price:120,tone:'skincare',tag:'AT-HOME CARE',accent:'#c09a53',label:'TURMERIC MASK',description:'A turmeric and sea moss-inspired facial mask. Always read the final instructions and avoid use on irritated skin.'},
    {id:'batana-oil',title:'Batana Oil 50ml',type:'dropper',category:'Skincare',price:150,tone:'skincare',tag:'NATURAL OILS',accent:'#947243',label:'BATANA OIL',description:'A natural oil for your personal care routine. Check the final label for suitable application and allergy guidance.'},
    {id:'honey-bundle',title:'Raw Honey Sea Moss Gel — 3 Jars',type:'bundle',category:'Combos',price:499,tone:'bundle',tag:'BUNDLE VALUE',accent:'#c0a75c',label:'HONEY BUNDLE',description:'Three jars of Raw Honey Sea Moss Gel 375ml. Save R98 compared with purchasing three single jars at R199 each.'},
    {id:'skincare-combo',title:'SeaMercy Skincare Combo',type:'combo',category:'Combos',price:349,tone:'bundle',tag:'BUNDLE',accent:'#9cafa2',label:'SKINCARE COMBO',description:'A skincare bundle. Included items and exact sizes will be confirmed before payment.'},
    {id:'detox-combo',title:'SeaMercy Wellness + Skincare Combo',type:'combo',category:'Combos',price:499,tone:'bundle',tag:'BUNDLE',accent:'#839a69',label:'WELLNESS COMBO',description:'A mix of wellness and skincare essentials. Confirm each included product before ordering.'}
  ];
  const byId = Object.fromEntries(products.map(p => [p.id,p]));
  const $ = (selector, root=document) => root.querySelector(selector);
  const $$ = (selector, root=document) => [...root.querySelectorAll(selector)];
  const money = amount => 'R' + Number(amount).toLocaleString('en-ZA', {maximumFractionDigits:0});
  const esc = text => String(text).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  let cart = readCart();
  let activeCategory = 'All';
  let searchTerm = '';
  let activeSlide = 0;
  let slideTimer;
  let openedProduct = null;
  let toastTimer;
  let offerShown = false;
  let exitShown = false;
  function readCart(){try {let saved=JSON.parse(localStorage.getItem('seamercy-demo-cart')||'{}');return Object.fromEntries(Object.entries(saved).filter(([id,q])=>byId[id]&&Number.isInteger(q)&&q>0&&q<=99));}catch{return {};}}
  function saveCart(){try{localStorage.setItem('seamercy-demo-cart',JSON.stringify(cart));}catch{}}
  function svgImage(p){
    const ink='#244e42'; const primary=esc(p.accent); const label=esc(p.label);
    let art='';
    const defs=`<defs><linearGradient id="glass" x1="0" x2="1"><stop offset="0" stop-color="#506b51"/><stop offset=".17" stop-color="${primary}"/><stop offset=".4" stop-color="#f4e4ad"/><stop offset=".73" stop-color="${primary}"/><stop offset="1" stop-color="#4c684e"/></linearGradient><linearGradient id="cap" x1="0" x2="1"><stop stop-color="#947240"/><stop offset=".25" stop-color="#e5ca8e"/><stop offset=".65" stop-color="#c5964d"/><stop offset="1" stop-color="#8c6a36"/></linearGradient><linearGradient id="paper" x1="0" x2="1"><stop stop-color="#e6dcb6"/><stop offset=".4" stop-color="#fffbde"/><stop offset="1" stop-color="#d1c99c"/></linearGradient></defs>`;
    const jar=(x, y, scale, t=label)=>`<g transform="translate(${x} ${y}) scale(${scale})"><ellipse cx="160" cy="278" rx="93" ry="14" fill="#173e2d" opacity=".12"/><rect x="91" y="75" width="138" height="191" rx="25" fill="url(#glass)" stroke="#71927d" stroke-width="2"/><path d="M95 96Q94 76 112 72L215 72Q231 76 226 96" fill="#fff" opacity=".14"/><rect x="86" y="49" width="148" height="40" rx="9" fill="url(#cap)"/><ellipse cx="160" cy="49" rx="74" ry="13" fill="#e2c283"/><rect x="91" y="127" width="138" height="112" rx="3" fill="url(#paper)" stroke="#c5b78b"/><text x="160" y="148" font-size="10" text-anchor="middle" font-family="Arial" font-weight="700" letter-spacing="2.2" fill="${ink}">SEAMERCY</text><text x="160" y="167" font-size="19" text-anchor="middle" font-family="Georgia" fill="${ink}">✺</text><text x="160" y="190" font-size="16" text-anchor="middle" font-family="Georgia" font-weight="700" fill="${ink}">SEA MOSS</text><text x="160" y="207" font-size="15" text-anchor="middle" font-family="Georgia" fill="${ink}">GEL</text><text x="160" y="226" font-size="8" text-anchor="middle" font-family="Arial" font-weight="700" fill="${ink}">${t}</text><text x="160" y="253" font-size="8" text-anchor="middle" font-family="Arial" fill="#f8f0dd">375ML</text></g>`;
    if(p.type==='gel'||p.type==='jar'){art=jar(0,0,1,p.type==='jar'?'FACE MASK':label);}
    else if(p.type==='bundle'){art=jar(-53,40,.8,'RAW HONEY')+jar(54,45,.8,'RAW HONEY')+jar(0,-3,1,'RAW HONEY');}
    else if(p.type==='combo'){art=jar(-47,45,.82,'CARE')+`<g transform="translate(115 52)"><rect x="0" y="48" width="106" height="197" rx="16" fill="url(#glass)"/><rect x="0" y="25" width="106" height="38" rx="9" fill="url(#cap)"/><rect x="8" y="125" width="90" height="85" rx="2" fill="url(#paper)"/><text x="53" y="154" font-size="10" text-anchor="middle" font-family="Arial" fill="${ink}" font-weight="700">SEAMERCY</text><text x="53" y="177" font-size="10" text-anchor="middle" font-family="Arial" fill="${ink}" font-weight="700">WELLNESS</text></g>`;}
    else if(p.type==='capsules'){art=`<ellipse cx="160" cy="292" rx="77" ry="12" fill="#000" opacity=".1"/><rect x="94" y="77" width="132" height="202" rx="20" fill="url(#glass)"/><rect x="90" y="48" width="140" height="50" rx="7" fill="url(#cap)"/><rect x="94" y="142" width="132" height="108" fill="url(#paper)"/><text x="160" y="165" text-anchor="middle" fill="${ink}" font-family="Arial" font-size="12" letter-spacing="1.5" font-weight="700">SEAMERCY</text><text x="160" y="185" text-anchor="middle" fill="${ink}" font-family="Georgia" font-size="16">✺</text><text x="160" y="207" text-anchor="middle" fill="${ink}" font-family="Arial" font-size="11" font-weight="700">${label.slice(0,24)}</text><text x="160" y="231" text-anchor="middle" fill="${ink}" font-family="Arial" font-size="9">CAPSULES</text>`;}
    else if(p.type==='dropper'){art=`<ellipse cx="160" cy="294" rx="75" ry="11" fill="#000" opacity=".11"/><rect x="103" y="107" width="114" height="167" rx="14" fill="url(#glass)"/><rect x="136" y="48" width="48" height="68" rx="10" fill="url(#cap)"/><rect x="145" y="25" width="30" height="36" rx="14" fill="#2f3b35"/><rect x="103" y="150" width="114" height="101" fill="url(#paper)"/><text x="160" y="176" text-anchor="middle" fill="${ink}" font-family="Arial" font-size="12" font-weight="700">SEAMERCY</text><text x="160" y="197" text-anchor="middle" fill="${ink}" font-family="Georgia" font-size="21">✺</text><text x="160" y="222" text-anchor="middle" fill="${ink}" font-family="Arial" font-size="11" font-weight="700">${label.slice(0,17)}</text>`;}
    else if(p.type==='soap'){art=`<g transform="rotate(-8 160 185)"><rect x="60" y="85" width="200" height="195" rx="15" fill="url(#paper)" stroke="#d6d3b5" stroke-width="4"/><rect x="73" y="98" width="174" height="170" rx="7" fill="none" stroke="#6b9987" stroke-width="2"/><text x="160" y="155" text-anchor="middle" fill="${ink}" font-family="Arial" font-size="14" font-weight="700">SEAMERCY</text><text x="160" y="193" text-anchor="middle" fill="${ink}" font-family="Georgia" font-size="38">✺</text><text x="160" y="230" text-anchor="middle" fill="${ink}" font-family="Arial" font-size="20" font-weight="700">GLOW SOAP</text></g>`;}
    return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 350">${defs}${art}</svg>`)}`;
  }
  const art = Object.fromEntries(products.map(p=>[p.id,svgImage(p)]));
  function renderProducts(){
    let list=products.filter(p=>(activeCategory==='All'||p.category===activeCategory)&&(p.title+' '+p.category+' '+p.label).toLowerCase().includes(searchTerm.toLowerCase()));
    const sort=$('#sort-products').value;
    if(sort==='price-asc')list.sort((a,b)=>a.price-b.price);
    if(sort==='price-desc')list.sort((a,b)=>b.price-a.price);
    if(sort==='name')list.sort((a,b)=>a.title.localeCompare(b.title));
    $('#product-total').textContent=`Showing ${list.length} of ${products.length} products`;
    $('#product-grid').innerHTML=list.length?list.map(p=>`<article class="product-card"><div class="product-image ${p.tone}"><span class="category-badge">${esc(p.tag)}</span><img class="product-art" src="${art[p.id]}" alt="Illustration of ${esc(p.title)} packaging" loading="lazy"/><span class="image-preview">Illustrative preview</span></div><div class="product-card-bottom"><span class="product-type">${esc(p.category.toUpperCase())}</span><h3>${esc(p.title)}</h3><div class="product-price">${money(p.price)}${p.id==='honey-bundle'?'<span class="bundle-savings">SAVE R98 vs singles</span>':''}</div><div class="card-actions"><button class="order-button" data-add="${p.id}">Add to bag +</button><button class="details-button" data-detail="${p.id}" aria-label="View details for ${esc(p.title)}">↗</button></div></div></article>`).join(''):'<p>No products match your search. Try another term or category.</p>';
  }
  function toast(msg){const el=$('#toast');el.textContent=msg;el.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('show'),2900);}
  function subtotal(){return Object.entries(cart).reduce((sum,[id,q])=>sum+byId[id].price*q,0);}
  function itemCount(){return Object.values(cart).reduce((a,b)=>a+b,0);}
  function deliveryCost(){const pref=$('#delivery-select').value;return pref==='locker'&&subtotal()>=700?0:DELIVERY[pref];}
  function addToCart(id){if(!byId[id])return;cart[id]=Math.min(99,(cart[id]||0)+1);saveCart();renderCart();toast(byId[id].title+' added to your bag');}
  function renderCart(){
    const count=itemCount();$('#cart-count').textContent=count;$('#cart-count').hidden=count===0;$('#drawer-count').textContent=`(${count})`;
    $('#cart-items').innerHTML=count?Object.entries(cart).map(([id,q])=>{const p=byId[id];return `<div class="cart-item"><div class="cart-thumb"><img src="${art[id]}" alt="" /></div><div class="cart-item-details"><strong>${esc(p.title)}</strong><small>${money(p.price)} each</small><div class="qty-actions"><button data-qty="${id}" data-delta="-1" aria-label="Remove one">−</button><span>${q}</span><button data-qty="${id}" data-delta="1" aria-label="Add one">+</button><button class="cart-remove" data-remove="${id}">Remove</button></div></div><strong>${money(p.price*q)}</strong></div>`;}).join(''):'<div class="empty-cart"><span class="empty-icon">◌</span><strong>Your bag is empty</strong><p>Discover a little ocean goodness in our collection.</p></div>';
    $('#cart-subtotal').textContent=money(subtotal());$('#cart-delivery').textContent=money(count?deliveryCost():0);$('#cart-total').textContent=money(subtotal()+(count?deliveryCost():0));$('#checkout-btn').disabled=count===0;
    $('#shipping-note').textContent=subtotal()>=700&&$('#delivery-select').value==='locker'?'Free PUDO locker delivery is estimated for qualifying orders. Coverage and availability must be confirmed.':`Delivery estimate only. ${$('#delivery-select').value==='locker'?'Free eligible PUDO locker delivery begins at R700.':'Availability and final cost confirmed before payment.'}`;
  }
  function qty(id,d){if(!byId[id])return;let next=(cart[id]||0)+d;if(next<1)delete cart[id];else cart[id]=Math.min(99,next);saveCart();renderCart();}
  function cartOpen(open){$('#cart-backdrop').hidden=!open;$('#cart-drawer').inert=!open;$('#cart-drawer').classList.toggle('visible',open);$('#cart-drawer').style.transform=open?'translateX(0)':'translateX(101%)';document.body.style.overflow=open?'hidden':'';if(open)$('#close-cart').focus();}
  function modalBackdrop(show){$('#modal-backdrop').hidden=!show;document.body.style.overflow=show?'hidden':'';}
  function modalClose(){clearInterval(slideTimer);$('#product-modal').hidden=true;$('#checkout-modal').hidden=true;$('#discover-modal').hidden=true;modalBackdrop(false);openedProduct=null;}
  function renderSlide(){if(!openedProduct)return;const modal=$('#product-modal');const labels=['Product illustration • front','Product illustration • side concept','Product illustration • back concept','Lifestyle photograph • awaiting approved asset','Lifestyle photograph • awaiting approved asset','Lifestyle photograph • awaiting approved asset','Testimonial screenshot • awaiting customer consent','Testimonial screenshot • awaiting customer consent','Testimonial screenshot • awaiting customer consent'];const photo=activeSlide<3;
    $('.modal-art',modal).innerHTML=`${photo?`<img src="${art[openedProduct.id]}" alt="Illustrative concept for ${esc(openedProduct.title)}" style="transform:rotate(${activeSlide===1?'-8':activeSlide===2?'8':'0'}deg)"/>`:'<div style="text-align:center;color:#789184;padding:55px"><div style="font-size:55px;line-height:1">✺</div><strong style="display:block;margin:12px 0;font-size:14px">Asset pending approval</strong><p style="font-size:12px">No fake lifestyle images or testimonials are displayed.</p></div>'}<button class="slide-arrow slide-prev" data-slide="prev" aria-label="Previous image">‹</button><button class="slide-arrow slide-next" data-slide="next" aria-label="Next image">›</button><span class="modal-slide-label">${labels[activeSlide]} (${activeSlide+1}/9)</span><div class="slide-dots">${Array.from({length:9},(_,i)=>`<button class="slide-dot ${activeSlide===i?'active':''}" data-slide="${i}" aria-label="View slide ${i+1}"></button>`).join('')}</div>`;
  }
  function restartSlides(){clearInterval(slideTimer);slideTimer=setInterval(()=>{activeSlide=(activeSlide+1)%9;renderSlide();},7000);}
  function changeSlide(which){if(!openedProduct)return;activeSlide=which==='next'?(activeSlide+1)%9:which==='prev'?(activeSlide+8)%9:Number(which);renderSlide();restartSlides();}
  function openDetails(id){const p=byId[id];if(!p)return;openedProduct=p;activeSlide=0;$('#product-modal').innerHTML=`<button class="modal-close" id="close-product" aria-label="Close product details">✕</button><div class="modal-product-grid"><div class="modal-art"></div><div class="modal-product-info"><p class="eyebrow"><span class="eyebrow-line"></span> ${esc(p.category.toUpperCase())}</p><h2>${esc(p.title)}</h2><p>${esc(p.description)}</p><strong class="modal-price">${money(p.price)}</strong><div class="modal-facts">✓ SeaMercy collection<br />✓ Provisional price · confirm before payment<br />✓ Delivery options available on enquiry</div><button class="btn btn-dark full-width" data-add="${p.id}">Add to bag <span>↗</span></button><p class="modal-hint">Packaging illustrations are placeholders. This listing does not make any medical claim.</p></div></div>`;renderSlide();modalBackdrop(true);$('#product-modal').hidden=false;restartSlides();$('#close-product').focus();}
  const stories=[
    {label:'EVERYDAY RITUALS',headline:'Make space for a little self-care.',text:'Your routine does not need to be complicated. Start with the habits that fit your lifestyle, and enjoy taking care of yourself one day at a time.'},
    {label:'SMOOTHIE INSPIRATION',headline:'Something good is blending.',text:'Try our free 30-day smoothie ideas. From berries and banana to mango and oats, explore a different combination when you feel like it.',link:'guide.html'},
    {label:'ABOUT SEAMERCY',headline:'Our story is still unfolding.',text:'Proudly based in Krugersdorp, SeaMercy brings ocean-inspired essentials and personal service into everyday wellness routines.',link:'#our-story'}
  ];
  function openDiscover(i){const s=stories[i];if(!s)return;$('#discover-modal-content').innerHTML=`<p class="eyebrow light"><span class="eyebrow-line"></span> ${s.label}</p><h2>${s.headline}</h2><p>${s.text}</p>${s.link?`<a class="btn btn-lime" href="${s.link}">Explore more ↗</a>`:''}<p style="margin-top:30px;font-size:10px">Concept editorial content. Videos can be added when approved media is available.</p>`;modalBackdrop(true);$('#discover-modal').hidden=false;$('#close-discover').focus();}
  function sendOrder(event){event.preventDefault();if(!itemCount())return;const name=$('#cust-name').value.trim(),email=$('#cust-email').value.trim(),phone=$('#cust-phone').value.trim();if(name.length<2||!email||phone.length<9)return;
    const items=Object.entries(cart).map(([id,q])=>`• ${byId[id].title} × ${q} — ${money(byId[id].price*q)}`).join('\n');
    const pref=$('#delivery-select').selectedOptions[0].text;const msg=`Hello SeaMercy! 🌊 I'd like to enquire about this order:\n\n${items}\n\nSubtotal: ${money(subtotal())}\nDelivery: ${pref}\nEstimated total: ${money(subtotal()+deliveryCost())}\n\nName: ${name}\nEmail: ${email}\nCell: ${phone}\n\nPlease confirm stock, pricing, delivery arrangements and payment details. This is an enquiry, not a paid order.`;
    const url=`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(msg)}`;const opened=window.open(url,'_blank');if(opened)opened.opener=null;else window.location.href=url;modalClose();toast('WhatsApp order enquiry prepared. No payment has been made.');
  }
  function chatAnswer(k){const answers={delivery:'We offer PUDO locker delivery and eligible door delivery, subject to confirmation. PUDO locker delivery is estimated free on qualifying orders R700+.',payment:'Add your favourites to your bag, select a delivery preference and send an enquiry on WhatsApp. Online Whop checkout is not active on this preview.',products:'Browse sea moss gels, skincare, wellness products and combo bundles in our collection. Product-specific details are available on each product card.',health:'I cannot diagnose health conditions or recommend products to treat illness. Please check labels and speak with a qualified healthcare professional for medical advice.'};$('#chat-response').textContent=answers[k]||answers.products;$('#chat-response').hidden=false;}
  function offer(which){if(!$('#guide-modal').hidden||!$('#exit-modal').hidden||!$('#modal-backdrop').hidden||!$('#cart-backdrop').hidden)return;$('#modal-backdrop').hidden=false;$('#'+which+'-modal').hidden=false;}
  function closeOffer(){ $('#guide-modal').hidden=true;$('#exit-modal').hidden=true;$('#modal-backdrop').hidden=true;document.body.style.overflow='';}
  function setupJar(){const build=(selector,n,r)=>{const node=$(selector);if(!node)return;for(let i=0;i<n;i++){const el=document.createElement('span');el.className='cylinder-panel';el.style.transform=`rotateY(${(i*360)/n}deg) translateZ(${r}px)`;node.appendChild(el);}};build('#jar-body-panels',20,106);build('#jar-lid-panels',22,108);
    const scene=$('#hero-jar-scene'),jar=$('#hero-jar');let yaw=-19,pitch=-6,drag=false,prevX=0,prevY=0,frame=0,last=0;const reduced=window.matchMedia('(prefers-reduced-motion: reduce)').matches;const set=()=>jar.style.transform=`rotateY(${yaw}deg) rotateX(${pitch}deg)`;set();
    scene.addEventListener('pointerdown',e=>{drag=true;prevX=e.clientX;prevY=e.clientY;scene.setPointerCapture(e.pointerId);});scene.addEventListener('pointermove',e=>{if(!drag)return;yaw+=(e.clientX-prevX)*.6;pitch=Math.max(-28,Math.min(20,pitch-(e.clientY-prevY)*.3));prevX=e.clientX;prevY=e.clientY;set();});scene.addEventListener('pointerup',()=>{drag=false;});scene.addEventListener('pointercancel',()=>{drag=false;});scene.addEventListener('keydown',e=>{if(e.key==='ArrowLeft'){yaw-=18;set();e.preventDefault();}if(e.key==='ArrowRight'){yaw+=18;set();e.preventDefault();}});
    if(!reduced){const animate=time=>{if(last&&!drag&&document.visibilityState==='visible'){yaw+=(time-last)*.003;set();}last=time;frame=requestAnimationFrame(animate);};frame=requestAnimationFrame(animate);window.addEventListener('pagehide',()=>cancelAnimationFrame(frame),{once:true});}
  }
  document.addEventListener('click',e=>{
    const add=e.target.closest('[data-add]');if(add){addToCart(add.dataset.add);return;}
    const det=e.target.closest('[data-detail]');if(det){openDetails(det.dataset.detail);return;}
    const change=e.target.closest('[data-slide]');if(change){changeSlide(change.dataset.slide);return;}
    const quantity=e.target.closest('[data-qty]');if(quantity){qty(quantity.dataset.qty,Number(quantity.dataset.delta));return;}
    const remove=e.target.closest('[data-remove]');if(remove){delete cart[remove.dataset.remove];saveCart();renderCart();return;}
    const story=e.target.closest('[data-discover]');if(story){openDiscover(Number(story.dataset.discover));return;}
    const ask=e.target.closest('[data-chat]');if(ask){chatAnswer(ask.dataset.chat);return;}
    const filter=e.target.closest('[data-category]');if(filter){activeCategory=filter.dataset.category;$$('.filter').forEach(b=>b.classList.toggle('active',b===filter));renderProducts();return;}
    if(e.target.closest('#close-product'))modalClose();
  });
  $('#sort-products').addEventListener('change',renderProducts);
  $('#delivery-select').addEventListener('change',renderCart);
  $('#open-cart').addEventListener('click',()=>cartOpen(true));
  $('#close-cart').addEventListener('click',()=>cartOpen(false));
  $('#cart-backdrop').addEventListener('click',()=>cartOpen(false));
  $('#checkout-btn').addEventListener('click',()=>{cartOpen(false);modalBackdrop(true);$('#checkout-modal').hidden=false;$('#cust-name').focus();});
  $('#close-checkout').addEventListener('click',modalClose);
  $('#checkout-form').addEventListener('submit',sendOrder);
  $('#close-discover').addEventListener('click',modalClose);
  $('#modal-backdrop').addEventListener('click',()=>{modalClose();closeOffer();});
  $('#menu-toggle').addEventListener('click',()=>{const nav=$('#main-nav');nav.classList.toggle('open');$('#menu-toggle').setAttribute('aria-expanded',nav.classList.contains('open'));});
  $$('#main-nav a').forEach(a=>a.addEventListener('click',()=>{$('#main-nav').classList.remove('open');$('#menu-toggle').setAttribute('aria-expanded','false');}));
  $('#search-toggle').addEventListener('click',()=>{$('#search-panel').hidden=!$('#search-panel').hidden;if(!$('#search-panel').hidden)$('#site-search').focus();});
  $('#site-search').addEventListener('input',e=>{searchTerm=e.target.value;renderProducts();});
  $('#site-search').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();$('#shop').scrollIntoView({behavior:'smooth'});$('#search-panel').hidden=true;}});
  $('#chat-fab').addEventListener('click',()=>{$('#chat-panel').hidden=!$('#chat-panel').hidden;});
  $('#close-chat').addEventListener('click',()=>{$('#chat-panel').hidden=true;});
  $('#faq-chat').addEventListener('click',()=>{$('#chat-panel').hidden=false;});
  $('#close-guide').addEventListener('click',closeOffer);$('#dismiss-guide').addEventListener('click',closeOffer);$('#close-exit').addEventListener('click',closeOffer);
  document.addEventListener('keydown',e=>{if(e.key==='Escape'){cartOpen(false);modalClose();closeOffer();$('#chat-panel').hidden=true;}});
  // Gentle offers appear once per browsing session. No fake gift eligibility is recorded.
  try{offerShown=sessionStorage.getItem('seamercy-guide-viewed')==='1';exitShown=sessionStorage.getItem('seamercy-exit-viewed')==='1';}catch{}
  if(!offerShown)setTimeout(()=>{if(!offerShown){offerShown=true;try{sessionStorage.setItem('seamercy-guide-viewed','1');}catch{}offer('guide');}},30000);
  document.addEventListener('mouseout',e=>{if(e.relatedTarget!==null||e.clientY>0||exitShown||window.innerWidth<900)return;exitShown=true;try{sessionStorage.setItem('seamercy-exit-viewed','1');}catch{}offer('exit');});
  $('#year').textContent=new Date().getFullYear();
  ["bundle-jar-a","bundle-jar-b","bundle-jar-c"].forEach(id=>{const im=document.createElement('img');im.src=art['honey-gel'];im.alt='Illustrative Sea Moss Gel jar';$('#'+id).appendChild(im);});
  renderProducts();renderCart();setupJar();
})();

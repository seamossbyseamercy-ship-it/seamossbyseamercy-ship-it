# SeaMercy — Interactive 3D E-Commerce Website Preview

An ocean-inspired, responsive storefront prototype for **SeaMercy Trading Enterprise (Pty) Ltd**, built from the owner's 3D e-commerce master brief.

## Preview locally

**Fastest method:** Open `index.html` in Chrome or another modern browser. The site uses plain HTML/CSS/JavaScript and needs no dependencies or npm installation.

**Recommended local server:** In the website folder, run `python -m http.server 8080` (or `python3 -m http.server 8080`), then open `http://localhost:8080`. In Codex, open the **folder** and ask it to continue from this working website.

## What is functional

- Fully responsive ocean-themed homepage, mobile navigation, responsive menu and product search.
- Interactive CSS 3D rotating Sea Moss Gel jar, draggable with touch/pointer and arrow keys (illustrative model, not a verified jar scan).
- **13 provisional products**, searchable, filterable and sortable; illustrated SVG placeholders.
- Product detail modal, nine-slide navigation with seven-second auto-advance. Slides 4–9 are honest placeholders pending approved lifestyle and consented testimonial assets.
- Shopping bag: add, remove, update quantities, subtotal, delivery estimate, free-locker threshold, browser-local cart persistence.
- Contact capture **only in the browser**, followed by a **WhatsApp order-enquiry handoff** with product breakdown. It is **not an online payment** and does not record paid orders.
- Discover editorial previews, Streetwave concept merchandise, affiliate information section, FAQs, customer-help FAQ demo.
- Free standalone `guide.html` with 30 smoothie ideas.
- Draft `policies.html` for delivery, returns, privacy, terms and health disclaimer.
- Session-limited promotional overlays, with no fake countdown, sales claims or fabricated testimonials.

## Before launch — critical

1. **Replace placeholders:** Supply authentic official SeaMercy logo (the site currently uses a *provisional text wordmark*, not an official logo), current product packshots, accurate 3D model or photographic rotation, approved product detail imagery, consented testimonials, ingredient lists, and lifestyle video content.
2. **Confirm catalogue:** The supplied master brief explicitly calls prices provisional. Current preview includes Plain Sea Moss Gel R150, Honey/Moringa/Hibiscus R199, three honey jars R499, capsules R349, etc. Verify every price, product, available size, contents, product claims and availability.
3. **Confirm contact channel:** Public WhatsApp number is presently configured as `27698926949` from prior SeaMercy setup. Check ownership before publishing. The affiliate enquiry button currently uses the same WhatsApp number.
4. **Confirm deliveries:** PUDO R80 estimate, eligible door R120 estimate, R700+ locker eligibility, geographic coverage and cold-chain shipping must be checked before live orders.
5. **Connect secure checkout:** Whop is *not* integrated. There are no Whop credentials or payment links in the input. Do not pretend orders are paid, and do not mark a payment complete from redirects. Use an audited server-side webhook with verified signatures, idempotency, and order validation once Whop's current checkout methods have been confirmed.
6. **Secure backend:** Build PostgreSQL + authenticated APIs for products, customers, orders, inventory, gift eligibility, verified promotions, payments, affiliate referral attribution and payouts, and staff-only CRM. Public HTML/localStorage cannot securely serve as the production source of truth.
7. **Gift eligibility:** Google Form link is included, but gift **redemption is disabled** until the backend verifies submissions, cart threshold and one-gift limit. No unverifiable free gift is issued.
8. **Email guide capture:** The 30-day guide is available directly without email capture in the demo. Add consent-based email delivery via a trusted backend and privacy policy before storing leads.
9. **Affiliate program:** The 10% to 20% scheme and R250 optional Academy are preview content; registration, authentication, distinct-customer verification, payout schedule and dashboards are not yet functional.
10. **AI chat:** The helper is a FAQ prototype, not OpenAI. Real AI requires a secure server-side key, content moderation, scoped product knowledge base, human escalation and privacy controls.
11. **Legal and regulatory:** Get appropriate professional review of POPIA, CPA, ECTA, product labelling and applicable health claims before production publication.
12. **Merchandise:** Streetwave graphics are concepts only; replace with approved designs, supplier-verified prices and live print-on-demand fulfilment.

## Suggested production migration

Use this as a UI prototype for a Next.js + TypeScript + React project with a real database. Recommended order:

1. Convert reusable storefront sections, product data and bag into typed React components.
2. Implement Prisma/PostgreSQL product, inventory, customer and order models; role-based authentication.
3. Add secure Whop order initiation, webhook validation, status reconciliation and refunds.
4. Build signed admin campaigns, content upload and consent-based gift verification.
5. Implement affiliate attribution and staff-only CRM with server-enforced permissions.
6. Integrate a server-side OpenAI API endpoint and keep private customer information out of model prompts unless appropriate.
7. Test E2E checkout, promo eligibility, WCAG reduced motion, network slowness, mobile flows and privacy handling.

## File map

- `index.html` — main storefront.
- `styles.css` — all site styling and motion preferences.
- `app.js` — products, SVG concepts, cart, search, modals, interaction.
- `guide.html` — free 30-day smoothie inspiration.
- `policies.html` — **draft** legal/policy copy.
- `assets/favicon.svg` — provisional wave icon.

## How to deploy this *preview*

Upload the folder to a static hosting platform (Netlify Drop, GitHub Pages, or any HTTPS static host). **Do not market it as a finished payment-taking e-commerce site.** Replace all provisional claims and contact details first, and do not publish a public admin dashboard without secure backend authentication.
